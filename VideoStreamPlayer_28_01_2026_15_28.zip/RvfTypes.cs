// Deprecated placeholder. RvfChunk moved to RvfReassembler.cs
namespace VideoStreamPlayer;

// Intentionally empty. Do not reintroduce RvfChunk here.
